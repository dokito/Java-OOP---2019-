package core;

import core.interfaces.ManagerController;

public class ManagerControllerImpl implements ManagerController {

    public ManagerControllerImpl() {
        //TODO:IMPLEMENT ME
    }

    @Override
    public String addPlayer(String type, String username) {
        return null;
    }

    @Override
    public String addCard(String type, String name) {
        return null;
    }

    @Override
    public String addPlayerCard(String username, String cardName) {
        return null;
    }

    @Override
    public String fight(String attackUser, String enemyUser) {
        return null;
    }

    @Override
    public String report() {
        return null;
    }
}
