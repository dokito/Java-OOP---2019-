package core;

public abstract class ManagerController {
}
